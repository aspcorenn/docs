### Huong dan cai dat tren iOS
Tại thư mục gốc (root)
 `npm install`

Tại thư muc  `ios` 

* Install Pods: `gem install cocoapods`
* Install Pods: `pod install`
* Install xcpretty: `gem install xcpretty`
* Launch: `open Sample.xcworkspace`

### Huong dan cai dat tren Android

* Có thể sử dụng Android Studio hoặc thiết bị thật: `adb reverse tcp:8081 tcp:8081`
* chạy từ server: `adb reverse tcp:3000 tcp:3000`
* chạy từ command line: `react-native run-android`

### Server

There is a server that the app hits for data. The data is only stored in memory, but it should produce a more realistic environment.

Trong thư mục  `server` 

* Install nvm and node-4.2.3
* Install dependencies: `npm install`
* Run it: `npm start`

Dữ liệu lưu ở file `models.js` . user là bleonard (password: "sample")


### Compiling

Dịch và chạy trên máy `npm run install:staging`